/* Content script entry point: watches the page, scores listings, renders UI,
 * and answers the toolbar popup.
 */
(async function () {
  "use strict";
  if (globalThis.__gjLoaded) return;
  globalThis.__gjLoaded = true;

  const api = globalThis.browser;
  const { score: scoreListing } = globalThis.GJScoring;
  const Store = globalThis.GJStore;
  const UI = globalThis.GJUI;

  let settings = await Store.getSettings();
  let collapsed = settings.startCollapsed;
  const dismissed = new Set(); // floating cards closed by the user, per listing
  const cardCache = new Map(); // id -> preview listing from search results (fills gaps on the detail view)
  const recordedCards = new Set();

  let current = null; // { key, sig, listing, result, report, host }
  let lastToolbar = null;

  function pickExtractor() {
    for (const ex of Object.values(globalThis.GJExtractors || {})) {
      if (ex.matches(location)) return ex;
    }
    return null;
  }

  async function buildCtx(L, reportsCache, empCache) {
    const reports = reportsCache || (await Store.getReports());
    let history;
    const empKey = L.platform + "|" + L.company;
    if (empCache && empCache.has(empKey)) history = empCache.get(empKey);
    else {
      history = await Store.getEmployer(L.platform, L.company);
      if (empCache) empCache.set(empKey, history);
    }
    return {
      history,
      flags: Store.employerFlags(reports, L.company),
      report: reports[`${L.platform}:${L.id}`] || null,
    };
  }

  // ---------------------------------------------------------------- toolbar
  function setToolbar(result) {
    const payload = result && settings.toolbarBadge ? { type: "GJ_SCORE", score: result.score, color: result.band.color } : { type: "GJ_CLEAR" };
    const k = JSON.stringify(payload);
    if (k === lastToolbar) return;
    lastToolbar = k;
    api.runtime.sendMessage(payload).catch(() => {});
  }

  // ---------------------------------------------------------------- detail card
  function removeCard() {
    if (current && current.host) current.host.remove();
    current = null;
    setToolbar(null);
  }

  function placeCard(host, anchor) {
    const floating = settings.cardPlacement === "floating" || !anchor || !anchor.el || !anchor.el.isConnected;
    if (floating) {
      if (host.parentNode !== document.body) document.body.appendChild(host);
    } else {
      const ok = anchor.where === "afterend" ? anchor.el.nextElementSibling === host : anchor.el.previousElementSibling === host;
      if (!ok) anchor.el.insertAdjacentElement(anchor.where, host);
    }
    return floating;
  }

  function drawCard(anchor) {
    if (!current) return;
    const show = settings.showCard && !dismissed.has(current.key);
    if (!show) {
      if (current.host) current.host.remove();
      return;
    }
    const floating = settings.cardPlacement === "floating" || !anchor || !anchor.el || !anchor.el.isConnected;
    const rerender = () => drawCard(current.anchor);
    current.host = UI.renderCard(current.result, {
      host: current.host,
      floating,
      collapsed,
      report: current.report,
      rerender,
      onToggle: (c) => {
        collapsed = c;
        rerender();
      },
      onClose: () => {
        dismissed.add(current.key);
        current.host.remove();
      },
      onFlag: (reason) => saveReport({ flag: reason }),
      onOutcome: (outcome) => saveReport({ outcome }),
    });
    placeCard(current.host, anchor);
  }

  async function saveReport(patch) {
    if (!current) return;
    await Store.saveReport(current.listing, patch);
    await rescoreCurrent();
  }

  async function rescoreCurrent() {
    if (!current) return;
    const ctx = await buildCtx(current.listing);
    current.result = scoreListing(current.listing, ctx);
    current.report = ctx.report;
    drawCard(current.anchor);
    setToolbar(current.result);
  }

  function signature(L) {
    return JSON.stringify([
      L.platform, L.id, L.title, L.company, L.location, L.ageDays && Math.round(L.ageDays), L.reposted,
      L.applicants, L.easyApply, L.externalApply, L.salaryListed, L.description ? L.description.length : -1,
      L.hiringContact, L.activelyReviewing, L.responsiveEmployer, L.employerActiveDays, L.companyRating, L.workplace, L.closed,
    ]);
  }

  async function scanDetail(ex) {
    const d = ex.extractDetail();
    if (!d) {
      const id = ex.currentJobId();
      if (current && current.listing.id !== id) removeCard();
      return;
    }
    const L = d.listing;

    // Fill gaps from the search card we saw for this listing.
    const cached = cardCache.get(L.id);
    if (cached) {
      if (L.ageDays == null && cached.ageDays != null) {
        L.ageDays = cached.ageDays;
        L.ageApprox = cached.ageApprox;
      }
      if (L.salaryListed !== true && cached.salaryListed === true) {
        L.salaryListed = true;
        L.salaryText = cached.salaryText;
      }
      if (L.companyRating == null && cached.companyRating != null) L.companyRating = cached.companyRating;
      if (L.easyApply == null && cached.easyApply) {
        L.easyApply = true;
        L.externalApply = false;
      }
      if (!L.reposted && cached.reposted) L.reposted = true;
      if (L.employerActiveDays == null && cached.employerActiveDays != null) L.employerActiveDays = cached.employerActiveDays;
      if (L.responsiveEmployer == null && cached.responsiveEmployer) L.responsiveEmployer = true;
      if (L.urgentlyHiring == null && cached.urgentlyHiring) L.urgentlyHiring = true;
    }

    const key = `${L.platform}:${L.id}`;
    const sig = signature(L);
    if (current && current.sig === sig) {
      current.anchor = d.anchor;
      if (settings.showCard && !dismissed.has(key) && (!current.host || !current.host.isConnected)) drawCard(d.anchor);
      else if (current.host && current.host.isConnected) placeCard(current.host, d.anchor);
      return;
    }

    const ctx = await buildCtx(L);
    const result = scoreListing(L, ctx);
    const host = current && current.key === key ? current.host : null;
    if (current && current.key !== key && current.host) current.host.remove();
    current = { key, sig, listing: L, result, report: ctx.report, host, anchor: d.anchor };
    drawCard(d.anchor);
    setToolbar(result);
    Store.recordListing(L, result.score).catch(() => {});
  }

  // ---------------------------------------------------------------- search results
  // Nothing is drawn in the results list (only the listing itself gets a score).
  // The list cards are still read: they supply details the detail view sometimes
  // hides (e.g. Indeed's posting age) and record sightings for repost detection.
  function scanCards(ex) {
    for (const c of ex.findCards()) {
      const L = c.listing;
      cardCache.set(c.id, L);
      if (L.company && !recordedCards.has(c.id)) {
        recordedCards.add(c.id);
        Store.recordListing(L, null).catch(() => {});
      }
    }
  }

  // ---------------------------------------------------------------- apply clicks
  document.addEventListener(
    "click",
    (e) => {
      if (!current) return;
      const t = e.target instanceof Element ? e.target : null;
      if (!t) return;
      const btn = t.closest(".jobs-apply-button, .jobs-s-apply button, #indeedApplyButton, .ia-IndeedApplyButton, #applyButtonLinkContainer a, #applyButtonLinkContainer button");
      if (!btn) return;
      if (current.report && current.report.appliedAt) return;
      Store.saveReport(current.listing, { appliedAt: Date.now() }).then(rescoreCurrent).catch(() => {});
    },
    true
  );

  // ---------------------------------------------------------------- scan loop
  let scanning = false;
  let pending = false;
  async function scan() {
    if (scanning) {
      pending = true;
      return;
    }
    scanning = true;
    try {
      const ex = pickExtractor();
      if (!ex) {
        removeCard();
        return;
      }
      scanCards(ex);
      await scanDetail(ex);
    } catch (err) {
      console.debug("[Ghost Job Detector]", err);
    } finally {
      scanning = false;
      if (pending) {
        pending = false;
        schedule();
      }
    }
  }

  let timer = null;
  function schedule(delay = 500) {
    clearTimeout(timer);
    timer = setTimeout(scan, delay);
  }

  new MutationObserver(() => schedule()).observe(document.documentElement, { childList: true, subtree: true });

  let lastHref = location.href;
  setInterval(() => {
    if (location.href !== lastHref) {
      lastHref = location.href;
      schedule(300);
    }
  }, 1000);

  api.storage.onChanged.addListener(async (changes, area) => {
    if (area !== "local") return;
    if (changes.settings) {
      settings = Object.assign({}, Store.DEFAULT_SETTINGS, changes.settings.newValue || {});
      if (current) {
        current.sig = null; // force redraw
        if (current.host) current.host.remove();
        current.host = null;
      }
      lastToolbar = null;
      schedule(50);
    } else if (changes.reports && current) {
      rescoreCurrent();
    }
  });

  api.runtime.onMessage.addListener((msg) => {
    if (!msg || typeof msg !== "object") return undefined;
    if (msg.type === "GJ_GET_STATE") {
      const ex = pickExtractor();
      return Promise.resolve({
        site: ex ? ex.name : null,
        listing: current
          ? { title: current.listing.title, company: current.listing.company, platform: current.listing.platform, id: current.listing.id }
          : null,
        result: current ? current.result : null,
        report: current ? current.report : null,
      });
    }
    if (msg.type === "GJ_DEBUG") {
      const ex = pickExtractor();
      let fresh = null;
      try {
        const d = ex && ex.extractDetail();
        if (d) {
          const L = d.listing;
          fresh = Object.assign({}, L, { description: L.description ? `${L.description.length} chars: ${L.description.slice(0, 160)}…` : null });
        }
      } catch (err) {
        fresh = { error: String(err) };
      }
      return Promise.resolve({
        version: api.runtime.getManifest().version,
        site: ex ? ex.name : null,
        path: location.pathname,
        jobId: ex ? ex.currentJobId() : null,
        extracted: fresh,
        score: current ? current.result.score : null,
        unknowns: current ? current.result.unknowns : null,
        details: ex && ex.debug ? ex.debug() : null,
      });
    }
    if (msg.type === "GJ_RESCAN") {
      if (current) current.sig = null;
      dismissed.clear();
      return scan().then(() => ({ ok: true }));
    }
    if (msg.type === "GJ_REPORT" && current) {
      return saveReport(msg.patch || {}).then(() => ({ ok: true }));
    }
    return undefined;
  });

  schedule(200);
  Store.prune().catch(() => {});
})();
