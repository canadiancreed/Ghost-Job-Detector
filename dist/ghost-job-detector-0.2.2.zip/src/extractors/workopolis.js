/* Workopolis (workopolis.com): two-pane search (?job=<key>) and /jobsearch/viewjob/<key> pages.
 * The site uses stable data-testid attributes; standalone job pages also embed JSON-LD.
 */
(function () {
  "use strict";
  const { q, qa, text, findSalary, detectWorkplace, parseRating, findDescription, describe, selectorReport, headings, parseShortAge, daysSince, readJobPostingLD } = globalThis.GJX;
  const DESC_SEL = ['[data-testid="viewJobBodyJobFullDescriptionContent"]', '[data-testid*="FullDescription"]'];
  let lastDebug = null;

  function matches(loc) {
    return /(^|\.)workopolis\.com$/.test(loc.hostname);
  }

  function currentJobId() {
    const u = new URL(location.href);
    const p = u.searchParams.get("job");
    if (p) return p;
    const m = u.pathname.match(/\/viewjob\/([^/?#]+)/);
    if (m) return m[1];
    return selectedCardId();
  }

  /** A fresh search (/search?q=...) shows the first job without putting its key in the URL.
   * Find the card matching the open pane: same title and company; if several match,
   * the highlighted one (the only card whose class differs from the rest). */
  function selectedCardId() {
    const title = text(q(document, ['[data-testid="viewJobTitle"]']));
    if (!title) return null;
    const company = text(q(document, ['[data-testid="viewJobCompanyName"] [data-testid="detailText"]', '[data-testid="viewJobCompanyName"]']));
    const cards = qa(document, ['[data-testid="searchSerpJob"][data-jobkey]']);
    const same = cards.filter((c) => {
      if (text(q(c, ['[data-testid="searchSerpJobTitle"]'])) !== title) return false;
      const cc = text(q(c, ['[data-testid="companyName"]']));
      return !company || !cc || cc === company;
    });
    if (same.length === 1) return same[0].getAttribute("data-jobkey");
    if (same.length > 1) {
      const counts = new Map();
      for (const c of cards) counts.set(c.className, (counts.get(c.className) || 0) + 1);
      const hl = same.filter((c) => counts.get(c.className) === 1);
      if (hl.length === 1) return hl[0].getAttribute("data-jobkey");
    }
    return null;
  }

  function cardFor(id) {
    for (const el of qa(document, ['[data-testid="searchSerpJob"][data-jobkey]'])) if (el.getAttribute("data-jobkey") === id) return el;
    return null;
  }

  function extractDetail() {
    const id = currentJobId();
    if (!id) return null;
    const titleEl = q(document, ['[data-testid="viewJobTitle"]']);
    const title = text(titleEl);
    const company = text(q(document, ['[data-testid="viewJobCompanyName"] [data-testid="detailText"]', '[data-testid="viewJobCompanyName"]']));
    if (!title || !company) return null;

    // Stale-pane guard: the URL changes before the pane re-renders.
    const card = cardFor(id);
    const cardTitle = card ? text(q(card, ['[data-testid="searchSerpJobTitle"]'])) : "";
    if (cardTitle && cardTitle !== title) return null;

    const location = text(q(document, ['[data-testid="viewJobCompanyLocation"] [data-testid="detailText"]', '[data-testid="viewJobCompanyLocation"]']));
    const body = q(document, ['[data-testid="viewJobBodyContainer"]']);
    const found = findDescription(body || document.body, DESC_SEL);
    let description = found && found.text.length >= 30 ? found.text : null;

    const ld = readJobPostingLD(title);
    if (!description && ld && ld.description) description = ld.description;

    const detailsText = text(q(document, ['[data-testid="viewJobBodyJobDetailsContainer"]']));
    const headText = text(q(document, ['[data-testid="viewJobHeadingContainer"]']));

    // Age: JSON-LD has the original posting date (standalone pages only); cards show "12d".
    let ageDays = ld ? daysSince(ld.datePosted) : null;
    let ageApprox = false;
    if (ageDays === null && card) {
      const a = parseShortAge(text(q(card, ['[data-testid="searchSerpJobDateStamp"]'])));
      if (a) {
        ageDays = a.days;
        ageApprox = a.approx;
      }
    }

    let salaryText = (ld && ld.salaryText) || findSalary(detailsText) || findSalary(headText);
    if (!salaryText && card) salaryText = findSalary(text(q(card, ['[data-testid^="salaryChip"]'])));
    let salaryListed = salaryText ? true : null;
    if (!salaryText && description) {
      const inDesc = findSalary(description);
      if (inDesc) {
        salaryListed = true;
        salaryText = `${inDesc} (in description)`;
      } else salaryListed = false;
    }

    const applyBtns = qa(document, ['[data-testid="viewJobHeaderFooterApplyButton"]']);
    const applyTxt = applyBtns.map((b) => text(b)).join(" ");
    const applyHref = applyBtns.map((b) => (b.getAttribute("href") || "") + " " + (b.getAttribute("data-mdref") || "")).join(" ");
    let easyApply = null;
    let externalApply = null;
    if (/quick apply|easily apply/i.test(applyTxt)) {
      easyApply = true;
      externalApply = false;
    } else if (applyBtns.length && (/\/out\?|company site/i.test(applyHref + " " + applyTxt) || /apply now/i.test(applyTxt))) {
      easyApply = false;
      externalApply = true;
    }

    const ratingEl = card && q(card, ['[data-testid="searchSerpJobCompanyRating"]']);
    const companyRating = ratingEl ? parseRating(ratingEl.getAttribute("aria-label") || text(ratingEl)) : null;

    const cardText = card ? text(card) : "";
    const workplace = (ld && ld.remote ? "remote" : null) || detectWorkplace(text(q(card, ['[data-testid^="remoteAttrChip"]']))) || detectWorkplace(location) || detectWorkplace(detailsText);

    const heading = q(document, ['[data-testid="viewJobHeadingContainer"]']);
    lastDebug = { titleEl: describe(titleEl), descEl: describe(found && found.el), descSource: found ? found.source : ld && ld.description ? "json-ld" : null, descLength: description ? description.length : 0, ld: !!ld, card: !!card };

    return {
      listing: {
        platform: "workopolis",
        id,
        url: `https://www.workopolis.com/jobsearch/viewjob/${id}`,
        title,
        company,
        location,
        ageDays,
        ageApprox,
        reposted: null,
        easyApply,
        externalApply,
        salaryListed,
        salaryText,
        description,
        urgentlyHiring: /urgently hiring/i.test(cardText + " " + headText) ? true : null,
        responsiveEmployer: /responsive employer|often responds/i.test(cardText) ? true : null,
        companyRating,
        ratingSource: "Workopolis",
        workplace,
        closed: /this job has expired|no longer available/i.test(headText) || (ld && ld.validThrough && Date.parse(ld.validThrough) < Date.now()) || false,
      },
      anchor: heading ? { el: heading, where: "afterend" } : titleEl ? { el: titleEl, where: "afterend" } : null,
    };
  }

  function findCards() {
    const out = [];
    for (const el of qa(document, ['[data-testid="searchSerpJob"][data-jobkey]'])) {
      const id = el.getAttribute("data-jobkey");
      const titleEl = q(el, ['[data-testid="searchSerpJobTitle"]']);
      if (!id || !titleEl) continue;
      const age = parseShortAge(text(q(el, ['[data-testid="searchSerpJobDateStamp"]'])));
      const salaryText = findSalary(text(q(el, ['[data-testid^="salaryChip"]'])));
      const ratingEl = q(el, ['[data-testid="searchSerpJobCompanyRating"]']);
      out.push({
        el,
        id,
        listing: {
          platform: "workopolis",
          id,
          preview: true,
          title: text(titleEl),
          company: text(q(el, ['[data-testid="companyName"]'])),
          location: text(q(el, ['[data-testid="searchSerpJobLocation"]'])),
          ageDays: age ? age.days : null,
          ageApprox: age ? age.approx : false,
          salaryListed: salaryText ? true : null,
          salaryText,
          easyApply: q(el, ['[data-testid="searchSerpJobQuickApply"]']) ? true : null,
          companyRating: ratingEl ? parseRating(ratingEl.getAttribute("aria-label") || "") : null,
        },
      });
    }
    return out;
  }

  function debug() {
    return {
      lastExtraction: lastDebug,
      documentTitle: document.title,
      selectorsMatched: selectorReport(document, {
        detail: ['[data-testid="viewJobTitle"]', '[data-testid="viewJobCompanyName"]', '[data-testid="viewJobCompanyLocation"]', '[data-testid="viewJobHeaderFooterApplyButton"]', '[data-testid="viewJobBodyJobDetailsContainer"]'],
        description: DESC_SEL,
        cards: ['[data-testid="searchSerpJob"]', '[data-testid="searchSerpJobDateStamp"]'],
        jsonld: ['script[type="application/ld+json"]'],
      }),
      headingsInPane: headings(q(document, ['[data-testid="viewJobBodyContainer"]']) || document.body),
    };
  }

  globalThis.GJExtractors = globalThis.GJExtractors || {};
  globalThis.GJExtractors.workopolis = { name: "Workopolis", matches, currentJobId, extractDetail, findCards, debug };
})();
