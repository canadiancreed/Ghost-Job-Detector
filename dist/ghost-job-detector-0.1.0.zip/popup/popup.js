"use strict";

const ORIGINS = ["*://*.linkedin.com/*", "*://*.indeed.com/*"];
const main = document.getElementById("main");

document.getElementById("opts").addEventListener("click", (e) => {
  e.preventDefault();
  browser.runtime.openOptionsPage();
  window.close();
});

function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === "class") el.className = v;
    else if (k === "style") el.setAttribute("style", v);
    else if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
    else el.setAttribute(k, v);
  }
  for (const kid of kids.flat()) {
    if (kid == null || kid === false) continue;
    el.append(kid instanceof Node ? kid : document.createTextNode(String(kid)));
  }
  return el;
}

function show(...nodes) {
  main.replaceChildren(...nodes);
}

function legend() {
  return h(
    "div",
    { class: "legend" },
    globalThis.GJScoring.BANDS.flatMap((b, i, arr) => [
      h("b", { style: `color:${b.color}` }, `${i === 0 ? 0 : arr[i - 1].max + 1}–${b.max}`),
      h("span", null, b.label),
    ])
  );
}

async function render() {
  const granted = await browser.permissions.contains({ origins: ORIGINS });
  if (!granted) {
    show(
      h("p", null, "Ghost Job Detector needs access to LinkedIn and Indeed to read job listings."),
      h("div", { class: "row" },
        h("button", {
          class: "primary",
          onclick: async () => {
            const ok = await browser.permissions.request({ origins: ORIGINS });
            if (ok) show(h("p", null, "Access granted. Reload any open LinkedIn or Indeed tabs."));
          },
        }, "Grant access")
      )
    );
    return;
  }

  const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
  let state = null;
  try {
    state = await browser.tabs.sendMessage(tab.id, { type: "GJ_GET_STATE" });
  } catch (_) {
    state = null;
  }

  if (!state || !state.site) {
    show(
      h("p", null, "Open a job listing on LinkedIn or Indeed to see its ghost-risk score."),
      h("p", { class: "muted" }, "Scores appear on the listing itself and as badges on search results."),
      legend()
    );
    return;
  }

  if (!state.result) {
    show(
      h("p", null, `On ${state.site}. Select a job to score it.`),
      h("div", { class: "row" }, h("button", { onclick: rescan }, "Rescan page")),
      legend()
    );
    return;
  }

  const r = state.result;
  const fmt = (p) => (p > 0 ? `+${p}` : p < 0 ? `${p}` : "·");
  show(
    h("div", { class: "job" }, h("div", { class: "t" }, state.listing.title), h("div", { class: "c" }, `${state.listing.company} · ${state.site}`)),
    h("div", { class: "head", style: `--band:${r.band.color}` },
      h("div", { class: "score" }, String(r.score)),
      h("div", null, h("div", { class: "muted" }, "Ghost Risk"), h("div", { class: "band" }, r.band.label))
    ),
    h("div", { class: "meter" }, h("i", { style: `left:${r.score}%` })),
    h("ul", null, r.signals.map((s) =>
      h("li", null, h("div", { class: `pts ${s.tone}` }, fmt(s.points)), h("div", { class: "sig" }, h("b", null, s.label), s.detail ? h("span", null, " — " + s.detail) : null))
    )),
    r.unknowns.length ? h("div", { class: "unknown" }, "Not shown on page (not counted): " + r.unknowns.join(", ") + ".") : null,
    h("div", { class: "row" },
      h("button", { onclick: rescan }, "Rescan"),
      h("button", { onclick: () => report({ flag: state.report && state.report.flag ? null : "other" }) }, state.report && state.report.flag ? "Remove flag" : "🚩 Flag ghost job")
    ),
    legend()
  );

  async function report(patch) {
    await browser.tabs.sendMessage(tab.id, { type: "GJ_REPORT", patch }).catch(() => {});
    render();
  }

  async function rescan() {
    await browser.tabs.sendMessage(tab.id, { type: "GJ_RESCAN" }).catch(() => {});
    render();
  }
}

async function rescan() {
  const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
  await browser.tabs.sendMessage(tab.id, { type: "GJ_RESCAN" }).catch(() => {});
  render();
}

render().catch((err) => show(h("p", null, "Something went wrong: " + err.message)));
