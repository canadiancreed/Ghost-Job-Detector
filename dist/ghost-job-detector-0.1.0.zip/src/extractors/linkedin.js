/* LinkedIn extractor. Works on the logged-in two-pane search, /jobs/view/ pages,
 * and the logged-out (guest) job pages. LinkedIn's markup changes often, so every
 * field has several selector fallbacks plus text-pattern fallbacks.
 */
(function () {
  "use strict";
  const { q, qa, text, blockText, parseAge, parseApplicants, findSalary, detectWorkplace } = globalThis.GJX;

  const ROOT_SEL = [
    ".jobs-search__job-details--container",
    ".jobs-search__job-details",
    ".job-view-layout",
    ".jobs-details",
    ".scaffold-layout__detail",
    ".details-pane__content",
    ".decorated-job-posting__details",
    "main",
  ];
  const TOP_CARD_SEL = [
    ".job-details-jobs-unified-top-card__container--two-pane",
    ".job-details-jobs-unified-top-card__container",
    ".jobs-unified-top-card",
    ".jobs-details-top-card",
    ".top-card-layout",
  ];
  const TITLE_SEL = [
    ".job-details-jobs-unified-top-card__job-title h1",
    ".job-details-jobs-unified-top-card__job-title",
    ".jobs-unified-top-card__job-title",
    "h1.top-card-layout__title",
    ".topcard__title",
    "h1",
  ];
  const COMPANY_SEL = [
    ".job-details-jobs-unified-top-card__company-name a",
    ".job-details-jobs-unified-top-card__company-name",
    ".jobs-unified-top-card__company-name",
    "a.topcard__org-name-link",
    ".topcard__flavor a",
    'a[href*="/company/"]',
  ];
  const META_SEL = [
    ".job-details-jobs-unified-top-card__tertiary-description-container",
    ".job-details-jobs-unified-top-card__primary-description-container",
    ".jobs-unified-top-card__subtitle-primary-grouping",
    ".topcard__flavor-row",
  ];
  const DESC_SEL = [
    "#job-details",
    ".jobs-description__content",
    ".jobs-description-content__text",
    ".jobs-box__html-content",
    ".description__text",
    ".show-more-less-html__markup",
  ];

  function matches(loc) {
    return /(^|\.)linkedin\.com$/.test(loc.hostname) && /^\/jobs/.test(loc.pathname);
  }

  function currentJobId() {
    const u = new URL(location.href);
    const p = u.searchParams.get("currentJobId");
    if (p) return p;
    const m = u.pathname.match(/\/jobs\/view\/(?:[^/]*?-)?(\d{6,})/);
    return m ? m[1] : null;
  }

  function idFromHref(href) {
    if (!href) return null;
    const m = href.match(/\/jobs\/view\/(?:[^/?]*?-)?(\d{6,})/) || href.match(/currentJobId=(\d{6,})/);
    return m ? m[1] : null;
  }

  function findRoot() {
    for (const s of ROOT_SEL) {
      const el = document.querySelector(s);
      if (el && q(el, DESC_SEL.concat(TITLE_SEL))) return el;
    }
    return document.body;
  }

  function cleanTitle(t) {
    return (t || "").replace(/\s+with verification\s*$/i, "").trim();
  }

  function extractDetail() {
    const id = currentJobId();
    if (!id) return null;
    const root = findRoot();
    const topCard = q(root, TOP_CARD_SEL);
    const titleEl = q(topCard || root, TITLE_SEL);
    let title = cleanTitle(text(titleEl));
    let company = text(q(topCard || root, COMPANY_SEL));

    if (!title || !company) {
      // Fallback to the document title: "Job Title | Company | LinkedIn"
      const parts = document.title.split(/\s+[|\-–]\s+/).map((s) => s.trim());
      if (parts.length >= 3 && /linkedin/i.test(parts[parts.length - 1])) {
        title = title || parts[0].replace(/^\(\d+\)\s*/, "");
        company = company || parts[1];
      }
    }
    if (!title || !company) return null;

    // Stale-pane guard: in two-pane search the URL changes before the pane re-renders.
    const titleLink = titleEl && (titleEl.closest("a") || titleEl.querySelector("a"));
    const linkedId = titleLink && idFromHref(titleLink.getAttribute("href"));
    if (linkedId && linkedId !== id) return null;

    const descEl = q(root, DESC_SEL);
    const descText = blockText(descEl);
    const description = descText.length >= 30 ? descText : null;

    const metaText = text(q(topCard || root, META_SEL));
    let topText = text(topCard);
    if (!topText) {
      const all = text(root);
      const cut = all.search(/about the job/i);
      topText = (cut > 0 ? all.slice(0, cut) : all.slice(0, 1500));
    }
    const headText = metaText + " · " + topText;

    // Posting age & reposts
    let age = parseAge(metaText) || parseAge(text(q(root, [".posted-time-ago__text", ".topcard__flavor--metadata"]))) || parseAge(topText);
    const timeEl = q(topCard || root, ["time[datetime]"]);
    if ((!age || age.days === null) && timeEl) {
      const t = Date.parse(timeEl.getAttribute("datetime"));
      if (!isNaN(t)) age = { days: Math.max(0, (Date.now() - t) / 86400000), approx: false, reposted: age ? age.reposted : false };
    }
    const reposted = /\breposted\b/i.test(headText) || (age && age.reposted) || false;

    // Applicants
    const appl = parseApplicants(headText) || parseApplicants(text(q(root, [".num-applicants__caption"])));

    // Location: first "·"-separated piece of the meta line
    let location = text(q(topCard || root, [".topcard__flavor--bullet", ".job-details-jobs-unified-top-card__bullet"]));
    if (!location && metaText) location = metaText.split("·")[0].trim();

    // Salary
    const salaryEl = q(root, [".job-details-fit-level-preferences", ".job-details-jobs-unified-top-card__job-insight", ".compensation__salary", ".salary"]);
    let salaryText = findSalary(text(salaryEl)) || findSalary(topText);
    let salaryListed = null;
    if (salaryText) salaryListed = true;
    else if (description) {
      const inDesc = findSalary(description);
      if (inDesc) {
        salaryListed = true;
        salaryText = `${inDesc} (in description)`;
      } else salaryListed = false;
    }

    // Apply button
    const rootText = text(root);
    const closed = /no longer accepting applications/i.test(rootText);
    let easyApply = null;
    let externalApply = null;
    const applyBtns = qa(root, [".jobs-apply-button", ".jobs-s-apply button", "button.apply-button", "a.apply-button"]);
    const applyTxt = applyBtns.map((b) => text(b) + " " + (b.getAttribute("aria-label") || "")).join(" ");
    if (/easy apply/i.test(applyTxt)) {
      easyApply = true;
      externalApply = false;
    } else if (/\bapply\b/i.test(applyTxt)) {
      // On LinkedIn a plain "Apply" (not Easy Apply) always sends you to the employer's site.
      easyApply = false;
      externalApply = true;
    }

    const hiringContact =
      /meet the hiring team|job poster/i.test(rootText) || !!q(root, [".hirer-card__hirer-information", ".job-details-people-who-can-help__section", ".hiring-team"])
        ? true
        : null;

    const activelyReviewing = /actively (reviewing|recruiting|hiring)/i.test(headText) ? true : null;

    const workplace = detectWorkplace(text(q(topCard || root, [".job-details-preferences-and-skills", ".job-details-fit-level-preferences"])) || metaText || topText);

    let anchor = null;
    if (topCard) anchor = { el: topCard, where: "afterend" };
    else if (descEl) anchor = { el: descEl.closest(".jobs-description, .jobs-box, article, section") || descEl, where: "beforebegin" };

    return {
      listing: {
        platform: "linkedin",
        id,
        url: `https://www.linkedin.com/jobs/view/${id}/`,
        title,
        company,
        location,
        ageDays: age && age.days !== null ? age.days : null,
        ageApprox: age ? age.approx : false,
        reposted,
        applicants: appl ? appl.count : null,
        applicantsText: appl ? appl.text : null,
        easyApply,
        externalApply,
        salaryListed,
        salaryText,
        description,
        hiringContact,
        activelyReviewing,
        workplace,
        closed,
      },
      anchor,
    };
  }

  const CARD_SEL = [
    "li[data-occludable-job-id]",
    "div.job-card-container[data-job-id]",
    "[data-job-id]",
    'div.base-card[data-entity-urn*="jobPosting"]',
    'div[data-view-name="job-card"]',
    "li.jobs-search-results__list-item",
  ];

  function cardId(el) {
    const d = el.dataset || {};
    if (d.occludableJobId) return d.occludableJobId;
    if (d.jobId && /^\d+$/.test(d.jobId)) return d.jobId;
    const urn = el.getAttribute("data-entity-urn") || "";
    const m = urn.match(/jobPosting:(\d+)/);
    if (m) return m[1];
    const a = el.querySelector('a[href*="/jobs/view/"], a[href*="currentJobId="]');
    return a ? idFromHref(a.getAttribute("href")) : null;
  }

  function findCards() {
    const cands = qa(document, CARD_SEL);
    const set = new Set(cands);
    const outer = cands.filter((el) => {
      for (let p = el.parentElement; p; p = p.parentElement) if (set.has(p)) return false;
      return true;
    });
    const seen = new Set();
    const out = [];
    for (const el of outer) {
      const id = cardId(el);
      if (!id || seen.has(id)) continue;
      const titleEl = q(el, [
        ".job-card-list__title--link strong",
        ".job-card-list__title--link",
        ".job-card-list__title",
        "a.job-card-container__link strong",
        "a.job-card-container__link",
        ".base-search-card__title",
        ".artdeco-entity-lockup__title",
        'a[href*="/jobs/view/"]',
      ]);
      if (!titleEl) continue; // occluded / not rendered yet
      seen.add(id);
      const cardText = text(el);
      const company = text(q(el, [".artdeco-entity-lockup__subtitle", ".job-card-container__primary-description", ".job-card-container__company-name", ".base-search-card__subtitle", "h4"]));
      const location = text(q(el, [".job-card-container__metadata-item", ".artdeco-entity-lockup__caption", ".job-search-card__location"]));
      let age = parseAge(text(q(el, ["time"]))) || parseAge(cardText);
      const timeEl = el.querySelector("time[datetime]");
      if ((!age || age.days === null) && timeEl) {
        const t = Date.parse(timeEl.getAttribute("datetime"));
        if (!isNaN(t)) age = { days: Math.max(0, (Date.now() - t) / 86400000), approx: true, reposted: !!(age && age.reposted) };
      }
      const salaryText = findSalary(cardText);
      const linkEl = titleEl.closest("a") || titleEl;
      out.push({
        el,
        id,
        badgeAnchor: { el: linkEl, where: "afterend" },
        listing: {
          platform: "linkedin",
          id,
          preview: true,
          title: cleanTitle(text(titleEl)),
          company,
          location,
          ageDays: age && age.days !== null ? age.days : null,
          ageApprox: age ? age.approx : false,
          reposted: /\breposted\b/i.test(cardText) || null,
          easyApply: /easy apply/i.test(cardText) ? true : null,
          salaryListed: salaryText ? true : null,
          salaryText,
          activelyReviewing: /actively (reviewing|recruiting|hiring)/i.test(cardText) ? true : null,
          closed: /no longer accepting/i.test(cardText) || null,
        },
      });
    }
    return out;
  }

  globalThis.GJExtractors = globalThis.GJExtractors || {};
  globalThis.GJExtractors.linkedin = { name: "LinkedIn", matches, currentJobId, extractDetail, findCards };
})();
